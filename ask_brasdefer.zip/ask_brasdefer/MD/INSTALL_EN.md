# ASK ARM WRESTLING — 2.3.1

Framework-independent FiveM multiplayer arm wrestling. OneSync is required.
ESX, QBCore and Qbox can run the resource without a framework integration in fixed
or standalone portable mode. ox_inventory and ox_target are optional.

## Install

1. Copy the `ask_brasdefer` folder into your server resources.
2. Enable OneSync and add `ensure ask_brasdefer` to `server.cfg`.
3. Keep `Config.Mode = 'fixed'` and edit `Config.Tables` for your locations.
4. Set `Config.Locale = 'en'` for English and restart the resource.

```lua
Config.Mode = 'fixed'
Config.TableModel = 'prop_table_03'
Config.Tables = {
    { coords = { x = 123.45, y = 456.78, z = 20.0 }, heading = 90.0, bucket = 0 },
}
```

Replace the sample coordinates. Use `/brascoords` in game to print a table entry in
F8. The position is measured from the placed prop; adjust the routing bucket for
your instance. An empty list disables fixed tables. Fixed props stream locally on
each client, while the server owns seats, match state, force and results.

## Controls

Joining picks the closest available seat relative to the table heading.
If a participant dies, the match is cancelled for both players and the table is
freed. The dead player stays dead; no winner is awarded.

- E: join a nearby table or push during a match.
- X: leave a match, including preparation and countdown.
- G: pick up your own idle portable table.
- Portable placement: E confirms, left/right rotate, Backspace cancels.
- `/jouerbras`, `/quitterbras`, `/rangerbras`: keyboard command alternatives.
- `/brasdefer`: start portable placement; configurable with `Config.Command`.
- `/brascoords`: print a fixed location in F8.

By default, a winner is selected after 20 seconds of active play without a natural win. The first player waits for an opponent
for up to 120 seconds. Both players must finish preparation before countdown.
The NUI does not capture keyboard or mouse focus. Notifications and all HUD
states use dark ASK panels with a green accent.

## Portable tables and inventories

Set `Config.Mode = 'portable'`:
- `Config.Inventory = 'standalone'`: free placement with owner/table limits.
- `ox`: require an ox_inventory item; start ox_inventory first.
- `auto`: use ox if it was started when the resource loaded, otherwise standalone.
- `custom`: implement the five synchronous functions in `Bridge.Custom`.

Custom mutations must return true only on actual success, without Wait/deferred
callbacks. `takeItem` returns `success, metadata`; carry/give must preserve metadata.
The default custom adapter refuses inventory operations until implemented.
ESX/QB inventories other than ox need a custom adapter if an item is required.

Optional ox_inventory item in `data/items.lua`:
```lua
['table_bras'] = {
    label = 'Arm wrestling table', weight = 5000, stack = true, close = true,
    consume = 0, client = { export = 'ask_brasdefer.utiliserTable' }
},
```
Keep `consume = 0`: the server removes the item after creating the table, and
returns its original metadata when picked up. A full inventory or failed removal
does not give a free table. Failed pickup restores the table.

Ownership defaults to the FiveM license, shared across characters. Replace
`Bridge.Custom.identifier` with a durable character identifier for per-character
ownership, including in ox mode. Do not use transient server IDs.
`Config.PlacementAce = 'brasdefer.place'` restricts portable placement to ACE;
nil allows everyone subject to configured limits.

## Settings and animations

`Config.Couleur.hex` controls the NUI accent.
`Config.NotificationDuration` is milliseconds.
`Config.NotificationLimit` is an integer from 1 to 5.
`Config.Debug` controls the startup information line; operational errors remain.

Seat 1 uses A clips; seat 2 uses B clips. Both sweep clips use the same global
animation phase. Force is signed globally; the personal HUD shows positive values
when the current player is winning. Nearby spectators in the same routing bucket
receive the server phase. Remote peds are corrected visually without requesting
their network ownership.

`Config.Animations` contains the dictionary, intro, idle, sweep and paired result
clips; `wins[winner][seat]` selects the result.
`DistanceJoueur` and `OffsetJoueurZ` adjust alignment to your prop.
`ReadyTimeout` must exceed two `LoadTimeout` plus `IntroDuration`.
A missing clip rejects preparation so the server can release both players.

## Automatic match result

    Config.AutoWinAfter = 20000 -- Active-match milliseconds; 0 disables.

Waiting, preparation and countdown are excluded. The leader wins at the timeout;
a tied score uses one server-side random selection shared by both players.
The timer is capped by Config.MaxDuelDuration (120 seconds by default).
If disabled, that limit ends the match as a draw. Natural wins end the match sooner.
Disconnects, deaths and instance changes cancel before awarding a result.
Timed wins use the normal winner/loser animations and cleanup. Restart after editing.

## Persistence and updates

Portable tables use resource KVP storage. Keep the same resource folder name,
back up server data, and pick up paid tables before changing inventory or switching
to fixed mode. Fixed mode leaves portable saves untouched.
Do not disable persistence with paid tables still placed. Inventory/KVP operations
are not an atomic transaction across an external inventory during a server crash.
Resource stops and disconnects release participants; matches are not persisted.

The NUI uses only local HTML/CSS/JS: no CDN, downloaded font or build dependency.
Configuration, translations, bridge, UI assets and guides are listed in
`escrow_ignore`. The project does not perform encryption.
Share the ask_brasdefer folder directly. No compilation tools or validation libraries are required.

## Checks after installation

Test both winning seats and a nearby spectator. Check table alignment with your
characters and props, different table headings, leaving a match, death,
disconnection, instance changes and a resource restart. Verify French/English,
portable placement and pickup, inventory capacity and preserved item metadata.

Technical reference: [FiveM NUI](https://docs.fivem.net/docs/scripting-manual/nui-development/full-screen-nui/).
