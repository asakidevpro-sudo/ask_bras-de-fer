# 2.3.1

- Sens des animations aligné sur la jauge et légère transparence des panneaux.
- Config.AutoWinAfter : victoire automatique après 20 secondes de duel actif par défaut.
- Le joueur en tête gagne ; égalité départagée par un seul tirage serveur.
- Valeur 0 pour désactiver ; durée plafonnée par MaxDuelDuration.
- Résultat, animations et nettoyage communs aux victoires naturelles et automatiques.
- Sélection de la place libre la plus proche, selon l'orientation de la table.

# 2.3.0

- Correspondance des clips A/B avec les places, progression commune de la paire.
- Introduction suivie d’une attente propre avant confirmation du joueur.
- Correction visuelle pour les spectateurs proches du même bucket.
- NUI ASK sombre/verte : notifications compactes, placement, attente, compte à rebours et jauge.
- Langues fr/en et animations configurables.
- Émissions NUI limitées aux changements et restauration après rechargement.
- Limitation des nouvelles tentatives de streaming pour un modèle indisponible.
- Diagnostics de démarrage configurables, erreurs utiles conservées.
- Guides d'installation français et anglais.
