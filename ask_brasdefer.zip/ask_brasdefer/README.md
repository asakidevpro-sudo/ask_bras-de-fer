# ASK BRAS DE FER — version 2.3.1

Interface dans la direction artistique ASK : cartes sombres, accent vert, notifications
compactes en haut au centre et panneau de duel en bas. La ressource fonctionne
indépendamment d’ASK MENU STAFF. [English guide](MD/INSTALL_EN.md).

Ressource FiveM indépendante du framework : ESX, QBCore, Qbox ou serveur sans
framework. **OneSync est requis.** Aucune dépendance ox n'est obligatoire.

## Installation

1. Copier le dossier `ask_brasdefer` dans les ressources.
2. Activer OneSync et ajouter `ensure ask_brasdefer` dans `server.cfg`.
3. Par défaut, `Config.Mode = 'fixed'` : définir les emplacements dans `Config.Tables`
   et le modèle dans `Config.TableModel`. Aucun inventaire n'est utilisé dans ce mode.

```lua
Config.Mode = 'fixed'
Config.TableModel = 'prop_table_03'
Config.Tables = {
    { coords = { x = 123.45, y = 456.78, z = 20.0 }, heading = 90.0, bucket = 0 },
}
```

Les coordonnées ci-dessus sont un exemple à remplacer. `config.lua` contient
l'emplacement demandé pour la base de développement. Une liste vide désactive
toutes les tables fixes. Aller à l'emplacement souhaité en jeu,
se tourner dans l'orientation souhaitée et saisir `/brascoords`. La console F8
affiche une ligne prête à copier ; la hauteur correspond à l'origine du prop posé
au sol. Le bucket vaut 0 par défaut : l'ajuster pour une autre instance.
Redémarrer la ressource après modification du fichier. Chaque table fixe réapparaît
au même emplacement après un redémarrage ou une suppression accidentelle.
Les joueurs ne peuvent ni déplacer ni récupérer les tables fixes.

Les props fixes sont créés **localement côté client** : aucune création d'objet
côté serveur dans ce mode. Chaque joueur voit une copie à la même position ;
les places, le compte à rebours, la force et la victoire restent gérés par le
serveur. ox_target utilise `addLocalEntity` pour ces tables. Les props sont chargés
à proximité (`FixedStreamingDistance`) et supprimés à l'arrêt de la ressource.

Optimisation : une seule lecture de position et un seul parcours des tables par
cycle de proximité ; distances au carré sans racines ni vecteurs temporaires.
Les listes inchangées ne sont pas renvoyées aux clients. Les changements de table
déclenchent une synchronisation, les changements de bucket sont détectés sous
environ une seconde, et la vérification de secours utilise `SyncInterval` (20 s).
L'interface et les touches sont traitées chaque frame uniquement près d'une table
ou pendant un duel/placement. Les coûts restent proportionnels au nombre de tables.

Pour conserver les tables portables, choisir `Config.Mode = 'portable'`, puis
choisir `Config.Inventory` dans `config.lua` :
   - `standalone` : tables gratuites via commande, avec une limite par propriétaire.
   - `ox` : item obligatoire ; démarrer ox_inventory avant cette ressource.
   - `auto` : ox s'il est déjà lancé au démarrage, sinon standalone.
   - `custom` : implémenter les cinq fonctions de `Bridge.Custom` dans `bridge.lua`.
     Elles refusent les opérations tant qu'elles ne sont pas configurées.

Migration depuis la version 1 : récupérer toutes les tables posées avant de
redémarrer avec la version 2. L'ancienne version n'enregistrait pas leur propriété
sur disque et la nouvelle version ne peut pas reconstruire ces informations.

Passage du mode portable au mode fixe : récupérer les tables portables d'abord.
Leurs sauvegardes KVP sont conservées sans être chargées ni modifiées en mode fixe.

Le mode choisi reste fixe jusqu'au redémarrage. L'arrêt d'ox_inventory ne bascule
jamais vers des tables gratuites. Un changement de mode ne permet pas de convertir
une ancienne table en item : rétablir le mode initial pour la récupérer.

## Commandes et touches

Le joueur prend la place libre la plus proche, selon l'orientation de la table.
Si un participant meurt, le duel est annulé pour les deux joueurs et la table
redevient libre. Le joueur mort reste mort ; aucun vainqueur n'est désigné.

- `/brascoords` : relever un emplacement pour `Config.Tables` dans F8.
- `/brasdefer` : placer une table en mode portable (nom configurable).
- `/jouerbras` : rejoindre la table proche.
- `/rangerbras` : récupérer sa table portable proche.
- `/quitterbras` : quitter et libérer les participants.
- Placement : E confirme, flèches tournent, Retour arrière annule.
- Près d'une table : E rejoint, G récupère sa propre table libre.
- Duel : E pousse, X quitte. Par défaut, un vainqueur est désigné après 20 secondes sans victoire naturelle.

ox_target est utilisé automatiquement s'il est lancé et `UseTarget` vaut true.
Les interactions au clavier restent disponibles. Notifications, aide de placement,
attente, compte à rebours, résultat et jauge utilisent la même NUI. Elle ne prend
ni focus clavier ni souris : les touches du jeu continuent de fonctionner.

## Item ox_inventory

Ajouter à `ox_inventory/data/items.lua` :

```lua
['table_bras'] = {
    label = 'Table de bras de fer',
    weight = 5000,
    stack = true,
    close = true,
    consume = 0,
    client = { export = 'ask_brasdefer.utiliserTable' }
},
```

`consume = 0` est indispensable : le serveur retire l'item après création de la
table. Ses métadonnées sont conservées et rendues lors de la récupération.

## Identité, permissions et sauvegarde

Par défaut la propriété utilise la licence FiveM, donc elle est partagée entre
les personnages d'un même compte. Pour une propriété par personnage, remplacer
`Bridge.Custom.identifier` par l'identifiant durable du personnage chargé,
même en mode ox. Ne pas utiliser `source`, qui change à la reconnexion.

`Config.PlacementAce = 'brasdefer.place'` restreint le placement à une permission
ACE. Avec nil, tous les joueurs peuvent poser une table selon leur mode inventaire.

En mode portable, les tables sont sauvegardées dans les KVP de la ressource, puis recréées au
redémarrage. Garder le même nom de ressource et sauvegarder les données serveur.
La déconnexion du propriétaire conserve la table. Les duels ne sont pas restaurés.
Les routing buckets doivent être rétablis par votre serveur pour revoir leurs tables.

Ne pas désactiver la persistance avec des tables payées encore posées : récupérer
les tables avant ce changement. Une restauration complète/crash ne constitue pas
une transaction atomique avec un inventaire externe : une interruption précisément
entre la mutation d'inventaire et la sauvegarde peut demander une correction admin.
Pour une garantie transactionnelle, intégrer l'adaptateur à votre stockage métier.

Les fonctions d'inventaire personnalisées doivent être synchrones (sans `Wait`
ni callback différé), retourner des booléens et préserver les métadonnées.
`takeItem` retourne `success, metadata`. L'identifiant doit être une chaîne durable.
Le mode custom permet de brancher l'inventaire de votre framework ; les inventaires
ESX/QB non ox ne sont pas détectés automatiquement. Utiliser standalone si aucun
adaptateur n'est souhaité, ou custom si un item doit être obligatoire.

## Interface et langues

```lua
Config.Locale = 'fr' -- 'en' pour l’anglais
Config.Couleur = { r = 34, g = 219, b = 128, hex = '#22DB80' }
Config.NotificationDuration = 5000
Config.NotificationLimit = 3 -- entier entre 1 et 5
Config.Debug = false -- masque le message d’initialisation uniquement
```

Modifier `locales.lua` pour les textes anglais ; les textes français servent de clés.
Redémarrer la ressource après modification. Aucun CDN, police distante ou outil de
compilation n’est nécessaire. Les erreurs de sauvegarde/inventaire restent visibles
dans la console. Le HUD est envoyé seulement lorsqu’un état ou une valeur change.

## Animations et progression

La place 1 utilise les clips A, la place 2 les clips B. Introduction, attente,
duel et résultat utilisent des clips associés à chaque rôle. Les deux clips de
duel partagent la **même progression globale** ; inverser la phase d’un participant
désynchronise la paire. Le serveur décide de la force et du gagnant.

`Config.Animations` permet de remplacer le dictionnaire et les clips. Préserver
l’ordre des rôles dans `intro`, `idle`, `sweep` et `wins[gagnant][place]`.
`IntroDuration` contrôle le temps d’introduction avant confirmation du joueur.
`ReadyTimeout` doit dépasser deux `LoadTimeout` plus `IntroDuration`.

Les participants et les spectateurs proches dans le même bucket appliquent la
phase reçue du serveur. Aucun contrôle réseau du personnage adverse n’est demandé.
L’alignement avec un prop personnalisé reste à régler avec `DistanceJoueur` et
`OffsetJoueurZ`.

## Victoire automatique

    Config.AutoWinAfter = 20000 -- 20 secondes de duel actif ; 0 désactive

Après ce délai, le joueur en tête gagne. Si la force est à zéro, le serveur tire
une des deux places au sort une seule fois et envoie le même résultat aux deux
participants. Les animations de victoire/défaite et la libération de la table
restent celles d'une victoire naturelle.

L'attente, la préparation et le compte à rebours ne comptent pas dans le délai.
La durée est plafonnée par Config.MaxDuelDuration. Avec AutoWinAfter = 0, cette
limite redevient un match nul. Un départ, une mort ou un changement de bucket
annule toujours le duel avant toute victoire automatique. Redémarrer après modification.

## Distribution

La ressource est proposée gratuitement. Partager directement le dossier
ask_brasdefer avec son manifeste, sa configuration, ses scripts, sa NUI et ses
guides. Aucun outil de compilation ou bibliothèque de validation n'est nécessaire.

La configuration, le bridge personnalisable, les traductions et les assets NUI
restent modifiables. Aucune encryption n'est appliquée par ce projet.
Ne pas changer le nom du dossier d'une installation portable existante :
les sauvegardes KVP dépendent du nom de ressource.

## Vérifications en jeu

Tester à deux joueurs : attente, départ durant préparation/compte à rebours,
victoire puis départ immédiat et nouveau duel, mort, changement de bucket,
déconnexion/reconnexion du propriétaire, inventaire plein, redémarrage de la
ressource, disparition de l'objet, démarrage/arrêt d'ox_target et ox_inventory.
Vérifier l'alignement des bras avec votre modèle ; `OffsetJoueurZ` et
`DistanceJoueur` permettent l'ajustement. Le délai limite les macros sans les éliminer.

Références : [événements FiveM](https://docs.fivem.net/docs/developers/server-security/),
[création serveur](https://docs.fivem.net/docs/scripting-manual/migrating-from-other-platforms/),
[items ox_inventory](https://overextended.dev/docs/ox_inventory/Guides/creatingItems).
