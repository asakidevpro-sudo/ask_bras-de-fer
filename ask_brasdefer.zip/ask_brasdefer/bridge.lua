Bridge = {}
local mode = Config.Inventory
if Config.Mode == 'fixed' then mode = 'standalone' end
if mode == 'auto' then
    mode = GetResourceState('ox_inventory') == 'started' and 'ox' or 'standalone'
end
assert(mode == 'standalone' or mode == 'ox' or mode == 'custom', BRAS_L('Config.Inventory invalide'))
Bridge.mode = mode

-- Adapter ces fonctions pour un autre inventaire et/ou une identité par personnage.
-- Une mutation doit retourner true seulement après confirmation réelle.
Bridge.Custom = {
    identifier = function(player) return GetPlayerIdentifierByType(player, 'license') end,
    hasItem = function(player) return false end,
    takeItem = function(player) return false end,
    canCarry = function(player, metadata) return false end,
    giveItem = function(player, metadata) return false end
}
local function invoke(fn, ...)
    local ok, result, extra = pcall(fn, ...)
    if not ok then
        print((BRAS_L('[brasdefer] Erreur inventaire : %s')):format(result))
        return false
    end
    return result, extra
end
function Bridge.identifier(player)
    local value = invoke(Bridge.Custom.identifier, player)
    return type(value) == 'string' and value ~= '' and value or nil
end
function Bridge.hasItem(player)
    if mode == 'standalone' then return true end
    if mode == 'custom' then return invoke(Bridge.Custom.hasItem, player) == true end
    return invoke(function() return (exports.ox_inventory:Search(player, 'count', Config.Item) or 0) > 0 end)
end
function Bridge.takeItem(player)
    if mode == 'standalone' then return true end
    if mode == 'custom' then
        local success, metadata = invoke(Bridge.Custom.takeItem, player)
        return success == true, metadata
    end
    return invoke(function()
        local slots = exports.ox_inventory:Search(player, 'slots', Config.Item)
        for _, slot in pairs(slots or {}) do
            if slot.count > 0 then
                local success = exports.ox_inventory:RemoveItem(player, Config.Item, 1, slot.metadata, slot.slot)
                return success == true, slot.metadata
            end
        end
        return false
    end)
end
function Bridge.canCarry(player, metadata)
    if mode == 'standalone' then return true end
    if mode == 'custom' then return invoke(Bridge.Custom.canCarry, player, metadata) == true end
    return invoke(function() return exports.ox_inventory:CanCarryItem(player, Config.Item, 1, metadata) end)
end
function Bridge.giveItem(player, metadata)
    if mode == 'standalone' then return true end
    if mode == 'custom' then return invoke(Bridge.Custom.giveItem, player, metadata) == true end
    return invoke(function() return exports.ox_inventory:AddItem(player, Config.Item, 1, metadata) == true end)
end
