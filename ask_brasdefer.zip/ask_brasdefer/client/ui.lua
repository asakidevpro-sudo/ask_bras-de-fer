-- Display only: the NUI never owns match rules or game controls.
BRAS_UI = {}
local ready, lastHud = false, nil
local queue = {}
local function send(message)
    if ready then SendNUIMessage(message) end
end
function BRAS_UI.hud(data)
    local unchanged = lastHud ~= nil
    for key, value in pairs(data) do
        if not lastHud or lastHud[key] ~= value then unchanged = false; break end
    end
    if unchanged then
        for key in pairs(lastHud) do if data[key] == nil then unchanged = false; break end end
    end
    if unchanged then return end
    lastHud = data
    send({ action = 'hud', data = data })
end
function BRAS_UI.hide()
    if not lastHud then return end
    lastHud = nil
    send({ action = 'hide' })
end
function BRAS_UI.notify(text, kind)
    local message = { action = 'notify', text = text, kind = kind or 'info',
        title = BRAS_L('BRAS DE FER'), duration = Config.NotificationDuration }
    if ready then send(message)
    else
        queue[#queue + 1] = message
        if #queue > Config.NotificationLimit then table.remove(queue, 1) end
    end
end
RegisterNUICallback('ready', function(_, cb)
    ready = true
    cb({ ok = true, locale = Config.Locale == 'en' and 'en' or 'fr',
        color = Config.Couleur.hex, limit = Config.NotificationLimit })
    if lastHud then send({ action = 'hud', data = lastHud }) else send({ action = 'hide' }) end
    for _, message in ipairs(queue) do send(message) end
    queue = {}
end)
