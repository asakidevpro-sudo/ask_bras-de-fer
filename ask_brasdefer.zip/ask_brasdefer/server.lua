local tables, placements, rates = {}, {}, {}
local syncSignatures = {}
local playerBuckets = {}
local nextId, sessionId = 0, 0
local stopping, storageReady = false, false
local storageKey = 'brasdefer:tables:v2'
local portable = Config.Mode == 'portable'
assert(portable or Config.Mode == 'fixed', BRAS_L('Config.Mode doit être fixed ou portable'))
assert(Config.ForceMax > 0 and Config.DelaiPoussee > 0, BRAS_L('Force/délai invalides'))
assert(Config.DistanceTarget <= Config.DistanceSecurite and Config.DistancePlacement <= Config.DistanceSecurite,
    BRAS_L('La distance de sécurité doit couvrir les interactions et le placement'))

assert(type(Config.IntroDuration) == 'number' and Config.IntroDuration >= 0
    and Config.IntroDuration + Config.LoadTimeout * 2 < Config.ReadyTimeout,
    'Config.ReadyTimeout must cover table/animation loading and IntroDuration')
assert(type(Config.NotificationLimit) == 'number' and Config.NotificationLimit % 1 == 0
    and Config.NotificationLimit >= 1 and Config.NotificationLimit <= 5, 'Config.NotificationLimit must be an integer from 1 to 5')

assert(Config.AutoWinAfter == nil or (type(Config.AutoWinAfter) == 'number'
    and Config.AutoWinAfter >= 0 and Config.AutoWinAfter < math.huge),
    'Config.AutoWinAfter must be a non-negative number of milliseconds (0 disables)')

local function message(player, text, kind) TriggerClientEvent('brasdefer:message', player, text, kind or 'error') end
local function validId(id)
    return type(id) == 'number' and id == math.floor(id) and id > 0 and id <= 2147483647
end
local function finite(n) return type(n) == 'number' and n == n and math.abs(n) < 100000 end
local function rate(player, action, delay)
    local now = GetGameTimer()
    rates[player] = rates[player] or {}
    if rates[player][action] and now - rates[player][action] < delay then return false end
    rates[player][action] = now
    return true
end
local function newSession() sessionId = sessionId + 1; return sessionId end
local function save()
    if not portable or not Config.Persistence or not storageReady then return end
    local records = {}
    for id, t in pairs(tables) do
        records[#records + 1] = { id = id, owner = t.owner, coords = t.coords,
            heading = t.heading, bucket = t.bucket, inventory = t.inventory, metadata = t.metadata }
    end
    SetResourceKvp(storageKey, json.encode(records))
end
local function spawn(t)
    -- Les tables fixes sont des objets locaux chez chaque client. Le serveur
    -- gère uniquement leur identité et les duels, sans native de création.
    if t.fixed then return true end
    local now = GetGameTimer()
    if t.nextSpawnAttempt and now < t.nextSpawnAttempt then return false end
    t.nextSpawnAttempt = now + Config.SpawnRetryDelay
    local c = t.coords
    local ok, entity = pcall(CreateObjectNoOffset, Config.TableModel, c.x, c.y, c.z, true, true, false)
    if not ok or not entity or entity == 0 or not DoesEntityExist(entity) then
        print((BRAS_L('[brasdefer] Création impossible pour la table %s (%.4f, %.4f, %.4f) : %s. Nouvelle tentative dans %d ms.'))
            :format(t.id or 'portable', c.x, c.y, c.z, tostring(entity), Config.SpawnRetryDelay))
        return false
    end
    t.entity = entity
    SetEntityRoutingBucket(entity, t.bucket)
    SetEntityOrphanMode(entity, 2)
    -- Orientation et gel appliqués localement par le propriétaire réseau après
    -- streaming. Aucun RPC de ces natives vers un client absent au démarrage.
    return true
end
local function view(t, player)
    return { id = t.id, fixed = t.fixed == true,
        netId = not t.fixed and NetworkGetNetworkIdFromEntity(t.entity) or nil, coords = t.coords,
        heading = t.heading, mine = not t.fixed and t.owner == Bridge.identifier(player), state = t.state,
        session = t.session, force = t.force, players = { first = t.players[1], second = t.players[2] } }
end
local function sync(player, force)
    local list, signature = {}, {}
    local bucket = GetPlayerRoutingBucket(player)
    playerBuckets[player] = bucket
    for _, t in pairs(tables) do
        if (t.fixed or (t.entity and DoesEntityExist(t.entity))) and t.bucket == bucket then
            local entry = view(t, player)
            list[#list + 1] = entry
            signature[#signature + 1] = ('%d:%s:%s:%s:%s:%s:%s'):format(t.id, t.state,
                tostring(entry.netId), tostring(entry.mine), tostring(t.session),
                tostring(t.players[1]), tostring(t.players[2]))
        end
    end
    table.sort(signature)
    local key = tostring(bucket) .. '|' .. table.concat(signature, '|')
    if not force and syncSignatures[player] == key then return end
    syncSignatures[player] = key
    TriggerClientEvent('brasdefer:tables', player, list)
end
local function broadcast() for _, player in ipairs(GetPlayers()) do sync(tonumber(player)) end end
local function near(player, t)
    local ped = GetPlayerPed(player)
    return ped ~= 0 and DoesEntityExist(ped) and GetEntityHealth(ped) > 100
        and t.bucket == GetPlayerRoutingBucket(player)
        and #(GetEntityCoords(ped) - vector3(t.coords.x, t.coords.y, t.coords.z)) <= Config.DistanceSecurite
end
local function reset(t, reason)
    for _, player in pairs(t.players) do TriggerClientEvent('brasdefer:annulerDuel', player, t.session, reason) end
    t.players, t.ready, t.force = {}, {}, 0
    t.session, t.state, t.since = newSession(), 'idle', GetGameTimer()
end
-- Natural and timed victories share the normal result and cleanup path.
local function finish(t, winner)
    if t.state ~= 'active' then return end
    t.state, t.since = 'ending', GetGameTimer()
    for _, participant in pairs(t.players) do
        TriggerClientEvent('brasdefer:finDuel', participant, t.session, winner)
    end
end
-- Use the same table-relative positions as client placement, for any heading.
local function closestFreeSeat(player, t)
    if t.players[1] and t.players[2] then return nil end
    if t.players[1] then return 2 end
    if t.players[2] then return 1 end
    local position = GetEntityCoords(GetPlayerPed(player))
    local angle = math.rad(t.heading)
    local dx, dy = math.sin(angle) * Config.DistanceJoueur, -math.cos(angle) * Config.DistanceJoueur
    local x, y = position.x - t.coords.x, position.y - t.coords.y
    local first = (x - dx) * (x - dx) + (y - dy) * (y - dy)
    local second = (x + dx) * (x + dx) + (y + dy) * (y + dy)
    return first <= second and 1 or 2
end
local function occupied(player)
    for _, t in pairs(tables) do
        if t.players[1] == player or t.players[2] == player then return true end
    end
    return false
end

RegisterNetEvent('brasdefer:demanderTables', function(force)
    local player = source
    if rate(player, 'sync', 2000) then sync(player, force == true) end
end)
RegisterNetEvent('brasdefer:demanderPlacement', function()
    local player = source
    if not portable then return message(player, BRAS_L('Les tables fixes sont définies dans config.lua.')) end
    if stopping or not storageReady or not rate(player, 'placement', 1500) then return end
    if placements[player] or occupied(player) then return message(player, BRAS_L('Une action est déjà en cours.')) end
    if Config.PlacementAce and not IsPlayerAceAllowed(player, Config.PlacementAce) then
        return message(player, BRAS_L('Tu ne peux pas placer de table.'))
    end
    local owner = Bridge.identifier(player)
    if not owner then return message(player, BRAS_L('Identité du joueur indisponible.')) end
    local count, total = 0, 0
    for _, t in pairs(tables) do
        total = total + 1
        if t.owner == owner then count = count + 1 end
    end
    if count >= Config.MaxTablesPerOwner or total >= Config.MaxTables then return message(player, BRAS_L('Limite de tables atteinte.')) end
    if not Bridge.hasItem(player) then return message(player, BRAS_L('Tu ne possèdes pas de table.')) end
    local token = newSession()
    placements[player] = { token = token, since = GetGameTimer(), owner = owner, bucket = GetPlayerRoutingBucket(player) }
    TriggerClientEvent('brasdefer:placementAutorise', player, token)
end)
RegisterNetEvent('brasdefer:annulerPlacement', function(token)
    local p = placements[source]
    if p and p.token == token then placements[source] = nil end
end)
RegisterNetEvent('brasdefer:enregistrerTable', function(token, coords, heading)
    local player = source
    if not portable then return end
    local p = placements[player]
    if not p or p.token ~= token then return end
    placements[player] = nil
    local function fail(text) TriggerClientEvent('brasdefer:placementResultat', player, token, false, text) end
    if stopping or GetGameTimer() - p.since > Config.DelaiPlacement then return fail(BRAS_L('Placement expiré.')) end
    if type(coords) ~= 'table' or not finite(coords.x) or not finite(coords.y)
        or not finite(coords.z) or not finite(heading) then return fail(BRAS_L('Position invalide.')) end
    if Bridge.identifier(player) ~= p.owner or GetPlayerRoutingBucket(player) ~= p.bucket or occupied(player) then
        return fail(BRAS_L('Ta situation a changé. Recommence le placement.'))
    end
    local t = { coords = { x = coords.x, y = coords.y, z = coords.z }, heading = heading % 360,
        bucket = p.bucket, owner = p.owner, inventory = Bridge.mode, state = 'idle',
        players = {}, ready = {}, force = 0, session = newSession(), since = GetGameTimer() }
    if not near(player, t) then return fail(BRAS_L('Position ou personnage indisponible.')) end
    local count, total = 0, 0
    for _, existing in pairs(tables) do
        total = total + 1
        if existing.owner == p.owner then count = count + 1 end
        if existing.bucket == t.bucket and #(vector3(coords.x, coords.y, coords.z)
            - vector3(existing.coords.x, existing.coords.y, existing.coords.z)) < 1.5 then
            return fail(BRAS_L('Une table est déjà trop proche.'))
        end
    end
    if count >= Config.MaxTablesPerOwner or total >= Config.MaxTables then return fail(BRAS_L('Limite de tables atteinte.')) end
    -- Création avant retrait : aucune perte d'item si l'objet ne peut être créé.
    if not spawn(t) then return fail(BRAS_L('Impossible de créer la table.')) end
    local success, metadata = Bridge.takeItem(player)
    if not success then DeleteEntity(t.entity); return fail(BRAS_L('Impossible de retirer la table de ton inventaire.')) end
    t.metadata = metadata
    nextId = nextId + 1
    t.id, tables[nextId] = nextId, t
    save()
    TriggerClientEvent('brasdefer:placementResultat', player, token, true, BRAS_L('Table installée.'))
    broadcast()
end)
RegisterNetEvent('brasdefer:recupererTable', function(id)
    local player = source
    if stopping or not storageReady or not validId(id) or not rate(player, 'recover', 1000) then return end
    local t = tables[id]
    if t and t.fixed then return message(player, BRAS_L('Cette table fixe ne peut pas être récupérée.')) end
    if not t or t.state ~= 'idle' or not near(player, t) then return message(player, BRAS_L('Table indisponible.')) end
    if t.owner ~= Bridge.identifier(player) then return message(player, BRAS_L('Cette table ne t’appartient pas.')) end
    if t.inventory ~= Bridge.mode then return message(player, BRAS_L('Rétablis le mode inventaire utilisé pour cette table.')) end
    if not Bridge.canCarry(player, t.metadata) then return message(player, BRAS_L('Inventaire indisponible ou plein.')) end
    t.state = 'recovering'
    local entity = t.entity
    if entity and DoesEntityExist(entity) then DeleteEntity(entity) end
    local deadline = GetGameTimer() + 2000
    while entity and DoesEntityExist(entity) and GetGameTimer() < deadline do Wait(50) end
    if stopping then return end
    if entity and DoesEntityExist(entity) then
        t.state = 'idle'
        return message(player, BRAS_L('La suppression a échoué. Tu peux réessayer.'))
    end
    -- Aucun item rendu avant confirmation de la suppression.
    if GetPlayerName(player) and Bridge.identifier(player) == t.owner
        and Bridge.canCarry(player, t.metadata) and Bridge.giveItem(player, t.metadata) then
        tables[id] = nil
        save()
        message(player, BRAS_L('Table récupérée.'), 'success')
    else
        t.entity, t.state = nil, 'idle'
        spawn(t) -- Le moniteur retentera si la création échoue.
        message(player, BRAS_L('Récupération annulée : l’inventaire n’a pas accepté la table.'))
    end
    broadcast()
end)
RegisterNetEvent('brasdefer:rejoindreTable', function(id)
    local player = source
    if stopping or not storageReady or not validId(id) or not rate(player, 'join', 750) then return end
    local t = tables[id]
    if not t or (t.state ~= 'idle' and t.state ~= 'waiting') or not near(player, t)
        or (not t.fixed and (not t.entity or not DoesEntityExist(t.entity))) then return message(player, BRAS_L('Table indisponible.')) end
    if occupied(player) or placements[player] then return message(player, BRAS_L('Une action est déjà en cours.')) end
    local firstParticipant = not t.players[1] and not t.players[2]
    local seat = closestFreeSeat(player, t)
    if not seat then return message(player, BRAS_L('Table indisponible.')) end
    if firstParticipant then t.session = newSession() end
    t.players[seat], t.ready[seat] = player, false
    t.state, t.since = t.players[1] and t.players[2] and 'preparing' or 'waiting', GetGameTimer()
    TriggerClientEvent('brasdefer:placerJoueur', player, view(t, player), seat, t.session)
    broadcast()
end)
RegisterNetEvent('brasdefer:joueurPret', function(id, session, success)
    local player = source
    if not validId(id) then return end
    local t = tables[id]
    if not t or t.session ~= session or (t.state ~= 'waiting' and t.state ~= 'preparing') then return end
    local seat = t.players[1] == player and 1 or (t.players[2] == player and 2 or nil)
    if not seat then return end
    if success ~= true or not near(player, t) then reset(t, BRAS_L('Impossible de préparer les joueurs.')); broadcast(); return end
    t.ready[seat] = true
    if t.players[1] and t.players[2] and t.ready[1] and t.ready[2] then
        t.state, t.since = 'countdown', GetGameTimer()
        for _, participant in pairs(t.players) do TriggerClientEvent('brasdefer:compteARebours', participant, session) end
        broadcast()
    end
end)
RegisterNetEvent('brasdefer:pousser', function(id, session)
    local player = source
    if not rate(player, 'push', Config.DelaiPoussee) or not validId(id) then return end
    local t = tables[id]
    if not t or t.session ~= session or t.state ~= 'active' then return end
    local seat = t.players[1] == player and 1 or (t.players[2] == player and 2 or nil)
    if not seat or not near(player, t) then return end
    t.force = math.max(-Config.ForceMax, math.min(Config.ForceMax, t.force + (seat == 1 and 1 or -1)))
    for _, participant in pairs(t.players) do TriggerClientEvent('brasdefer:mettreAJourForce', participant, session, t.force) end
    -- Spectators receive the authoritative phase only near this table, in its bucket.
    for _, value in ipairs(GetPlayers()) do
        local spectator = tonumber(value)
        if spectator ~= t.players[1] and spectator ~= t.players[2] and GetPlayerRoutingBucket(spectator) == t.bucket then
            local ped = GetPlayerPed(spectator)
            if ped ~= 0 and DoesEntityExist(ped) and #(GetEntityCoords(ped) - vector3(t.coords.x, t.coords.y, t.coords.z)) <= Config.FixedStreamingDistance then
                TriggerClientEvent('brasdefer:forceVisuelle', spectator, t.id, t.session, t.force)
            end
        end
    end
    if math.abs(t.force) >= Config.ForceMax then
        finish(t, t.force > 0 and 1 or 2)
        broadcast()
    end
end)
RegisterNetEvent('brasdefer:quitterTable', function(id, session)
    local player = source
    if not validId(id) then return end
    local t = tables[id]
    if t and t.session == session and (t.players[1] == player or t.players[2] == player) then
        reset(t, BRAS_L('Un joueur a quitté la table.'))
        broadcast()
    end
end)
AddEventHandler('playerDropped', function()
    local player = source
    placements[player], rates[player] = nil, nil
    syncSignatures[player] = nil
    playerBuckets[player] = nil
    for _, t in pairs(tables) do
        if t.players[1] == player or t.players[2] == player then reset(t, BRAS_L('Ton adversaire s’est déconnecté.')) end
    end
    broadcast()
end)
CreateThread(function()
    storageReady = true
    if not portable then
        assert(type(Config.Tables) == 'table', BRAS_L('Config.Tables doit être une liste'))
        -- Valider toute la liste avant de créer les objets.
        for index, definition in ipairs(Config.Tables) do
            local c = type(definition) == 'table' and definition.coords
            assert(type(c) == 'table' and finite(c.x) and finite(c.y) and finite(c.z)
                and finite(definition.heading or 0)
                and type(definition.bucket or 0) == 'number' and validId((definition.bucket or 0) + 1),
                (BRAS_L('Emplacement invalide dans Config.Tables[%d]')):format(index))
        end
        for index, definition in ipairs(Config.Tables) do
            local c = definition.coords
            local t = { id = index, fixed = true, coords = { x = c.x, y = c.y, z = c.z },
                heading = (definition.heading or 0) % 360, bucket = definition.bucket or 0,
                state = 'idle', players = {}, ready = {}, force = 0, session = newSession(), since = GetGameTimer() }
            tables[index] = t
            spawn(t)
        end
        if #Config.Tables == 0 then print(BRAS_L('[brasdefer] Aucun emplacement : remplir Config.Tables dans config.lua (/brascoords).')) end
    elseif Config.Persistence then
        local data = GetResourceKvpString(storageKey)
        local ok, records = pcall(json.decode, data or '[]')
        if ok and type(records) == 'table' then
            for _, r in ipairs(records) do
                if type(r) == 'table' and validId(r.id) and type(r.owner) == 'string' and type(r.coords) == 'table'
                    and finite(r.coords.x) and finite(r.coords.y) and finite(r.coords.z)
                    and finite(r.heading) and type(r.bucket) == 'number' and validId(r.bucket + 1)
                    and not tables[r.id]
                    and (r.inventory == 'standalone' or r.inventory == 'ox' or r.inventory == 'custom') then
                    r.state, r.players, r.ready, r.force = 'idle', {}, {}, 0
                    r.session, r.since = newSession(), GetGameTimer()
                    tables[r.id], nextId = r, math.max(nextId, r.id)
                    spawn(r)
                else storageReady = false end
            end
        else storageReady = false end
        if not storageReady then print(BRAS_L('[brasdefer] Sauvegarde invalide : placements et sauvegarde bloqués pour protéger les données.')) end
    end
    local count = 0
    for _ in pairs(tables) do count = count + 1 end
    if Config.Debug then
        print((BRAS_L('[brasdefer] Initialisation terminée : mode %s ; %d table(s) ; inventaire %s.'))
            :format(Config.Mode, count, Bridge.mode))
    end
    local nextBucketCheck = 0
    while not stopping do
        Wait(250)
        if stopping then break end
        local changed, now = false, GetGameTimer()
        if now >= nextBucketCheck then
            nextBucketCheck = now + 1000
            for _, value in ipairs(GetPlayers()) do
                local player = tonumber(value)
                if playerBuckets[player] ~= GetPlayerRoutingBucket(player) then sync(player) end
            end
        end
        for player, p in pairs(placements) do
            if now - p.since > Config.DelaiPlacement then
                placements[player] = nil
                TriggerClientEvent('brasdefer:placementResultat', player, p.token, false, BRAS_L('Placement expiré.'))
            end
        end
        for _, t in pairs(tables) do
            if t.state ~= 'recovering' then
                if not t.fixed and (not t.entity or not DoesEntityExist(t.entity)) then
                    if t.state ~= 'idle' then reset(t, BRAS_L('La table a disparu.')) end
                    if spawn(t) then changed = true end
                elseif t.state ~= 'idle' then
                    local invalid = false
                    for _, player in pairs(t.players) do
                        if not GetPlayerName(player) or not near(player, t) then invalid = true end
                    end
                    if invalid then reset(t, BRAS_L('Duel annulé : un joueur est indisponible.')); changed = true
                    elseif t.state == 'waiting' and not (t.ready[1] or t.ready[2]) and now - t.since > Config.ReadyTimeout then
                        reset(t, BRAS_L('La préparation a expiré.')); changed = true
                    elseif t.state == 'waiting' and now - t.since > Config.WaitingTimeout then
                        reset(t, BRAS_L('Le délai d’attente est dépassé.')); changed = true
                    elseif t.state == 'preparing' and now - t.since > Config.ReadyTimeout then
                        reset(t, BRAS_L('La préparation a expiré.')); changed = true
                    elseif t.state == 'countdown' and now - t.since >= Config.Countdown then
                        t.state, t.since, t.force = 'active', now, 0
                        for _, player in pairs(t.players) do TriggerClientEvent('brasdefer:demarrerDuel', player, t.session) end
                        changed = true
                    elseif t.state == 'active' and now - t.since >=
                        ((Config.AutoWinAfter or 0) > 0 and math.min(Config.AutoWinAfter, Config.MaxDuelDuration)
                            or Config.MaxDuelDuration) then
                        if (Config.AutoWinAfter or 0) > 0 then
                            local winner = t.force > 0 and 1 or (t.force < 0 and 2 or math.random(1, 2))
                            finish(t, winner)
                        else
                            reset(t, BRAS_L('Temps écoulé : match nul.'))
                        end
                        changed = true
                    elseif t.state == 'ending' and now - t.since >= Config.EndDuration then
                        reset(t); changed = true
                    end
                end
            end
        end
        if changed then broadcast() end
    end
end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    stopping = true
    save()
    for _, t in pairs(tables) do
        reset(t, BRAS_L('La ressource a été arrêtée.'))
        if t.entity and DoesEntityExist(t.entity) then DeleteEntity(t.entity) end
    end
end)
