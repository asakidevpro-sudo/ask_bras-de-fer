fx_version 'cerulean'
game 'gta5'

author 'Asaki'
description 'ASK ARM WRESTLING - Standalone multiplayer arm wrestling'
version '2.3.1'

shared_scripts { 'config.lua', 'locales.lua' }
server_scripts { 'bridge.lua', 'server.lua' }
client_scripts { 'client/ui.lua', 'client.lua' }

ui_page 'html/index.html'
files { 'html/index.html', 'html/style.css', 'html/script.js' }

dependency '/onesync'
escrow_ignore { 'config.lua', 'bridge.lua', 'locales.lua', 'html/*', 'README.md', 'MD/*.md' }
