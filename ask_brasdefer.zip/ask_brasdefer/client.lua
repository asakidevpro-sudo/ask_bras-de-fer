local tables, targets = {}, {}
local session, current, seat, duel, force, countdown, ending = nil, nil, nil, false, 0, nil, false
local frozenPed, placement, preview, placementSince = nil, nil, nil, nil
local pending, hint = false, nil
local initializedEntities = {}
local localTables, localLoading, localRetry = {}, {}, {}
local visualTables = {}
local preparing = false
local function tableEntity(t)
    if t.fixed then return localTables[t.id] or 0 end
    if NetworkDoesEntityExistWithNetworkId(t.netId) then return NetworkGetEntityFromNetworkId(t.netId) end
    return 0
end

local function notify(value, kind)
    BRAS_UI.notify(value, kind)
end
local function hud(kind, title, caption, extra)
    local data = { kind = kind, brand = BRAS_L('BRAS DE FER'), title = BRAS_L(title),
        caption = caption and BRAS_L(caption) or '' }
    for key, value in pairs(extra or {}) do data[key] = value end
    BRAS_UI.hud(data)
end
local function sweepPhase(value)
    -- A/B clips are a paired timeline. Both peds must use the same phase.
    return math.max(0.001, math.min(0.999, (Config.ForceMax + value) / (Config.ForceMax * 2)))
end
local function syncVisuals(t)
    if not t.players then return end
    local phase = sweepPhase(current == t.id and force or (t.force or 0))
    for number, id in pairs({ [1] = t.players.first, [2] = t.players.second }) do
        local player = GetPlayerFromServerId(id)
        if player ~= -1 then
            local ped = GetPlayerPed(player)
            local name = Config.Animations.sweep[number]
            if ped ~= frozenPed and DoesEntityExist(ped)
                and IsEntityPlayingAnim(ped, Config.Animations.dictionary, name, 3) then
                -- Local visual correction only: never take control of another player's ped.
                SetEntityAnimCurrentTime(ped, Config.Animations.dictionary, name, phase)
                SetEntityAnimSpeed(ped, Config.Animations.dictionary, name, 0.0)
            end
        end
    end
end
local function loadAsset(name, animation, valid)
    local deadline = GetGameTimer() + Config.LoadTimeout
    if animation then RequestAnimDict(name) else
        if not IsModelInCdimage(name) or not IsModelValid(name) then return false end
        RequestModel(name)
    end
    while not (animation and HasAnimDictLoaded(name) or not animation and HasModelLoaded(name)) do
        if GetGameTimer() > deadline or (valid and not valid()) then return false end
        Wait(25)
    end
    return not valid or valid()
end
local function cleanup()
    if frozenPed and DoesEntityExist(frozenPed) then
        FreezeEntityPosition(frozenPed, false)
        ClearPedTasksImmediately(frozenPed)
    end
    frozenPed, preparing = nil, false
    BRAS_UI.hide()
    session, current, seat, duel, force, countdown, ending = nil, nil, nil, false, 0, nil, false
end
local function quit()
    local id, old = current, session
    cleanup()
    if id then TriggerServerEvent('brasdefer:quitterTable', id, old) end
end
local function clearPlacement(cancel)
    local token = placement
    placement, pending, placementSince = nil, false, nil
    if preview and DoesEntityExist(preview) then DeleteObject(preview) end
    preview = nil
    BRAS_UI.hide()
    SetModelAsNoLongerNeeded(Config.TableModel)
    if cancel and token then TriggerServerEvent('brasdefer:annulerPlacement', token) end
end
local function animation(name, old, duration, flags)
    if not loadAsset(Config.Animations.dictionary, true, function() return session == old end) then return false end
    if not frozenPed or not DoesEntityExist(frozenPed) then return false end
    if GetAnimDuration(Config.Animations.dictionary, name) <= 0 then return false end
    TaskPlayAnim(frozenPed, Config.Animations.dictionary, name, 8.0, -8.0, duration, flags, 0.0, false, false, false)
    return true
end
local function targetNames(id) return { 'brasdefer_utiliser_' .. id, 'brasdefer_recuperer_' .. id } end
local function removeTargets()
    if GetResourceState('ox_target') == 'started' then
        for id, target in pairs(targets) do
            if target.localEntity then exports.ox_target:removeLocalEntity(target.entity, targetNames(id))
            else exports.ox_target:removeEntity(target.entity, targetNames(id)) end
        end
    end
    targets = {}
end
local function addTarget(t)
    if not Config.UseTarget or GetResourceState('ox_target') ~= 'started' then return end
    local id, names = t.id, targetNames(t.id)
    local entity = t.fixed and localTables[id] or t.netId
    if not entity or entity == 0 then return end
    local options = {
        { name = names[1], icon = 'fa-solid fa-hand-fist', label = BRAS_L('Faire un bras de fer'),
          distance = Config.DistanceTarget,
          canInteract = function()
              local v = tables[id]
              return not current and not placement and v and (v.state == 'idle' or v.state == 'waiting')
          end,
          onSelect = function() TriggerServerEvent('brasdefer:rejoindreTable', id) end },
        { name = names[2], icon = 'fa-solid fa-box', label = BRAS_L('Récupérer la table'),
          distance = Config.DistanceTarget,
          canInteract = function()
              local v = tables[id]
              return not current and not placement and v and v.mine and v.state == 'idle'
          end,
          onSelect = function() TriggerServerEvent('brasdefer:recupererTable', id) end }
    }
    if t.fixed then exports.ox_target:addLocalEntity(entity, options)
    else exports.ox_target:addEntity(entity, options) end
    targets[id] = { entity = entity, localEntity = t.fixed == true }
end
local function removeLocalTable(id)
    local target = targets[id]
    if target and target.localEntity and GetResourceState('ox_target') == 'started' then
        exports.ox_target:removeLocalEntity(target.entity, targetNames(id))
    end
    targets[id] = nil
    local entity = localTables[id]
    if entity and DoesEntityExist(entity) then DeleteObject(entity) end
    localTables[id], localRetry[id] = nil, nil
end
local function streamFixedTable(t)
    if not t.fixed or localLoading[t.id] or (localTables[t.id] and DoesEntityExist(localTables[t.id])) then return end
    if localRetry[t.id] and GetGameTimer() < localRetry[t.id] then return end
    localRetry[t.id] = GetGameTimer() + Config.SpawnRetryDelay
    localLoading[t.id] = true
    CreateThread(function()
        local id = t.id
        local function valid() return tables[id] == t end
        if loadAsset(Config.TableModel, false, valid) then
            local c = t.coords
            local entity = CreateObjectNoOffset(Config.TableModel, c.x, c.y, c.z, false, false, false)
            if entity ~= 0 then
                SetEntityHeading(entity, t.heading)
                FreezeEntityPosition(entity, true)
                localTables[id] = entity
                addTarget(t)
            end
            SetModelAsNoLongerNeeded(Config.TableModel)
        end
        localLoading[id] = nil
    end)
end
local function serverEvent(name, fn)
    RegisterNetEvent(name, function(...)
        if source ~= 65535 then return end
        fn(...)
    end)
end
serverEvent('brasdefer:message', notify)
serverEvent('brasdefer:tables', function(list)
    local updated = {}
    for _, t in ipairs(list) do updated[t.id] = t end
    for id, target in pairs(targets) do
        if not updated[id] or (not target.localEntity and updated[id].netId ~= target.entity) then
            if GetResourceState('ox_target') == 'started' then
                if target.localEntity then exports.ox_target:removeLocalEntity(target.entity, targetNames(id))
                else exports.ox_target:removeEntity(target.entity, targetNames(id)) end
            end
            targets[id] = nil
            initializedEntities[id] = nil
        end
    end
    for id in pairs(localTables) do if not updated[id] then removeLocalTable(id) end end
    -- Conserver la définition pendant un chargement asynchrone si elle est identique.
    for id, t in pairs(updated) do
        local old = tables[id]
        if old and t.fixed and old.fixed and old.heading == t.heading
            and old.coords.x == t.coords.x and old.coords.y == t.coords.y and old.coords.z == t.coords.z then
            old.state, old.mine = t.state, t.mine
            old.session, old.force, old.players = t.session, t.force, t.players
            updated[id] = old
        elseif localTables[id] then removeLocalTable(id) end
    end
    tables = updated
    for id, t in pairs(tables) do if not targets[id] then addTarget(t) end end
end)
serverEvent('brasdefer:placementResultat', function(token, success, message)
    if placement ~= token then return end
    clearPlacement(false)
    notify(message, success and 'success' or 'error')
end)
serverEvent('brasdefer:placementAutorise', function(token)
    if current or placement then TriggerServerEvent('brasdefer:annulerPlacement', token); return end
    placement, placementSince = token, GetGameTimer()
    if not loadAsset(Config.TableModel, false, function() return placement == token end) then
        if placement == token then clearPlacement(true); notify(BRAS_L('Impossible de charger la table.')) end
        return
    end
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    preview = CreateObjectNoOffset(Config.TableModel, c.x, c.y, c.z, false, false, false)
    if preview == 0 then clearPlacement(true); notify(BRAS_L('Impossible de créer la prévisualisation.')); return end
    FreezeEntityPosition(preview, true)
    SetEntityCollision(preview, false, false)
    SetEntityAlpha(preview, 150, false)
    local rotation = GetEntityHeading(ped)
    while placement == token and not pending do
        Wait(0)
        if placement ~= token then break end
        ped = PlayerPedId()
        if IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) or GetGameTimer() - placementSince > Config.DelaiPlacement then
            clearPlacement(true); notify(BRAS_L('Placement annulé.')); break
        end
        c = GetEntityCoords(ped)
        local forward = GetEntityForwardVector(ped)
        local x, y = c.x + forward.x * Config.DistancePlacement, c.y + forward.y * Config.DistancePlacement
        local ground, z = GetGroundZFor_3dCoord(x, y, c.z + 2.0, false)
        z = ground and z or c.z - 1.0
        if IsControlPressed(0, 174) then rotation = rotation - 90.0 * GetFrameTime() end
        if IsControlPressed(0, 175) then rotation = rotation + 90.0 * GetFrameTime() end
        SetEntityCoordsNoOffset(preview, x, y, z, false, false, false)
        SetEntityHeading(preview, rotation)
        PlaceObjectOnGroundProperly(preview)
        hud('placement', pending and BRAS_L('Installation en cours') or BRAS_L('Placer votre table'),
            BRAS_L('Choisissez un emplacement dégagé.'), {
                badge = BRAS_L('PLACEMENT'), primaryKey = 'E', primaryText = BRAS_L('Poser'),
                rotateKey = '← →', rotateText = BRAS_L('Tourner'),
                secondaryKey = 'BACK', secondaryText = BRAS_L('Annuler')
            })
        if IsControlJustPressed(0, 177) then clearPlacement(true)
        elseif IsControlJustPressed(0, 38) then
            if not ground then notify(BRAS_L('Sol introuvable : déplace-toi.')) else
                local p = GetEntityCoords(preview)
                pending = true
                hud('placement', BRAS_L('Installation en cours'), BRAS_L('Confirmation du serveur…'), { badge = BRAS_L('PLACEMENT') })
                TriggerServerEvent('brasdefer:enregistrerTable', token, { x = p.x, y = p.y, z = p.z }, rotation)
            end
        end
    end
end)
serverEvent('brasdefer:placerJoueur', function(t, number, old)
    if current or placement then TriggerServerEvent('brasdefer:joueurPret', t.id, old, false); return end
    if number ~= 1 and number ~= 2 then return end
    session, current, seat = old, t.id, number
    preparing = true
    hud('preparing', BRAS_L('Préparation du duel'), BRAS_L('Prenez place à la table.'), { secondaryKey = 'X', secondaryText = BRAS_L('Quitter') })
    if t.fixed then
        t = tables[t.id] or t
        streamFixedTable(t)
    end
    local deadline, entity = GetGameTimer() + Config.LoadTimeout, 0
    repeat
        if session ~= old then return end
        entity = tableEntity(t)
        if entity ~= 0 and DoesEntityExist(entity) then break end
        Wait(25)
    until GetGameTimer() >= deadline
    if session ~= old then return end
    if entity == 0 or not DoesEntityExist(entity) or IsPedInAnyVehicle(PlayerPedId(), false) then
        TriggerServerEvent('brasdefer:joueurPret', t.id, old, false); cleanup(); return
    end
    local ped, c = PlayerPedId(), GetEntityCoords(entity)
    frozenPed = ped
    local angle, sign = math.rad(t.heading), number == 1 and 1 or -1
    local x = c.x + math.sin(angle) * Config.DistanceJoueur * sign
    local y = c.y - math.cos(angle) * Config.DistanceJoueur * sign
    SetEntityCoords(ped, x, y, c.z + Config.OffsetJoueurZ, false, false, false, false)
    SetEntityHeading(ped, GetHeadingFromVector_2d(c.x - x, c.y - y))
    FreezeEntityPosition(ped, true)
    local success = animation(Config.Animations.intro[number], old, Config.IntroDuration, 0)
    if success then
        Wait(Config.IntroDuration)
        if session ~= old then return end
        success = animation(Config.Animations.idle[number], old, -1, 1)
    end
    if session == old then
        preparing = false
        TriggerServerEvent('brasdefer:joueurPret', t.id, old, success)
    end
end)
serverEvent('brasdefer:compteARebours', function(old)
    if session == old then
        countdown = GetGameTimer() + Config.Countdown
        if not animation(Config.Animations.idle[seat], old, -1, 1) and session == old then quit() end
    end
end)
serverEvent('brasdefer:demarrerDuel', function(old)
    if session ~= old or not current then return end
    force, duel, countdown = 0, true, nil
    local name = Config.Animations.sweep[seat]
    if not animation(name, old, -1, 1) then if session == old then quit() end; return end
    Wait(100)
    if session == old and duel then
        SetEntityAnimCurrentTime(frozenPed, Config.Animations.dictionary, name, sweepPhase(force))
        SetEntityAnimSpeed(frozenPed, Config.Animations.dictionary, name, 0.0)
    end
end)
serverEvent('brasdefer:mettreAJourForce', function(old, value)
    if session == old and duel and type(value) == 'number' and value == value then
        force = math.max(-Config.ForceMax, math.min(Config.ForceMax, value))
    end
end)
serverEvent('brasdefer:forceVisuelle', function(id, old, value)
    local t = tables[id]
    if t and t.session == old and t.state == 'active' and type(value) == 'number' and value == value then
        t.force = math.max(-Config.ForceMax, math.min(Config.ForceMax, value))
    end
end)
serverEvent('brasdefer:finDuel', function(old, winner)
    if session ~= old or (winner ~= 1 and winner ~= 2) then return end
    duel, ending, countdown = false, true, nil
    local name = Config.Animations.wins[winner][seat]
    notify(winner == seat and BRAS_L('VICTOIRE !') or BRAS_L('DÉFAITE'), winner == seat and 'success' or 'warning')
    animation(name, old, Config.EndDuration, 0)
end)
serverEvent('brasdefer:annulerDuel', function(old, reason)
    if session ~= old then return end
    cleanup()
    if reason then notify(reason, 'warning') end
end)
RegisterCommand(Config.Command, function()
    if Config.Mode == 'fixed' then return notify(BRAS_L('Configure les emplacements dans config.lua. /brascoords affiche ta position dans F8.')) end
    if not current and not placement then TriggerServerEvent('brasdefer:demanderPlacement') end
end, false)
RegisterCommand('brascoords', function()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    -- Chercher le sol, puis mesurer l'origine du prop réellement posé.
    local found, ground = GetGroundZFor_3dCoord(c.x, c.y, c.z + 2.0, false)
    if not found then return notify(BRAS_L('Sol introuvable : déplace-toi avant de relever la position.')) end
    if not loadAsset(Config.TableModel, false) then return notify(BRAS_L('Modèle de table invalide ou chargement impossible.')) end
    local object = CreateObjectNoOffset(Config.TableModel, c.x, c.y, ground, false, false, false)
    if object == 0 then return notify(BRAS_L('Impossible de mesurer la position du prop.')) end
    SetEntityVisible(object, false, false)
    SetEntityCollision(object, false, false)
    PlaceObjectOnGroundProperly(object)
    local p = GetEntityCoords(object)
    DeleteObject(object)
    SetModelAsNoLongerNeeded(Config.TableModel)
    print(('{ coords = { x = %.4f, y = %.4f, z = %.4f }, heading = %.2f, bucket = 0 },')
        :format(p.x, p.y, p.z, GetEntityHeading(ped)))
    notify(BRAS_L('Emplacement affiché dans F8 : copie la ligne dans Config.Tables. Ajuste bucket si nécessaire.'))
end, false)
RegisterCommand('quitterbras', quit, false)
local function distanceSquared(a, b)
    local x, y, z = a.x - b.x, a.y - b.y, a.z - b.z
    return x * x + y * y + z * z
end
local function closest()
    local c, best, distance = GetEntityCoords(PlayerPedId()), nil, Config.DistanceTarget
    distance = distance * distance
    for _, t in pairs(tables) do
        local d = distanceSquared(c, t.coords)
        if d < distance then best, distance = t, d end
    end
    return best
end
RegisterCommand('jouerbras', function()
    local t = closest()
    if t and not current and not placement then TriggerServerEvent('brasdefer:rejoindreTable', t.id) end
end, false)
RegisterCommand('rangerbras', function()
    local t = closest()
    if t and not current and not placement then TriggerServerEvent('brasdefer:recupererTable', t.id) end
end, false)
exports('utiliserTable', function(data)
    if Config.Mode == 'fixed' then return notify(BRAS_L('Les tables sont déjà définies dans config.lua.')) end
    if current or placement then return end
    if GetResourceState('ox_inventory') == 'started' and data then
        exports.ox_inventory:useItem(data, function(used)
            if used then TriggerServerEvent('brasdefer:demanderPlacement') end
        end)
    else TriggerServerEvent('brasdefer:demanderPlacement') end
end)
CreateThread(function()
    local lastPush = 0
    while true do
        if current then
            Wait(0)
            local ped = PlayerPedId()
            if (frozenPed and ped ~= frozenPed) or IsEntityDead(ped) then quit()
            elseif IsControlJustPressed(0, 73) then quit()
            else
                DisableControlAction(0, 24, true)
                DisableControlAction(0, 25, true)
                DisableControlAction(0, 37, true)
                local t = tables[current]
                local entity = t and tableEntity(t) or 0
                if entity ~= 0 then SetEntityNoCollisionEntity(ped, entity, true) end
                if duel then
                    hud('active', BRAS_L('À vous de jouer'), BRAS_L('Chaque poussée compte.'), {
                        badge = BRAS_L('DUEL'), primaryKey = 'E', primaryText = BRAS_L('Pousser'),
                        secondaryKey = 'X', secondaryText = BRAS_L('Quitter'),
                        ratio = (seat == 1 and force or -force) / Config.ForceMax,
                        opponent = BRAS_L('ADVERSAIRE'), you = BRAS_L('VOUS')
                    })
                    if IsControlJustPressed(0, 38) and GetGameTimer() - lastPush >= Config.DelaiPoussee then
                        lastPush = GetGameTimer()
                        TriggerServerEvent('brasdefer:pousser', current, session)
                    end
                    local name = Config.Animations.sweep[seat]
                    if IsEntityPlayingAnim(ped, Config.Animations.dictionary, name, 3) then
                        SetEntityAnimCurrentTime(ped, Config.Animations.dictionary, name, sweepPhase(force))
                        SetEntityAnimSpeed(ped, Config.Animations.dictionary, name, 0.0)
                    end
                elseif preparing then
                    hud('preparing', BRAS_L('Préparation du duel'), BRAS_L('Prenez place à la table.'), { secondaryKey = 'X', secondaryText = BRAS_L('Quitter') })
                elseif countdown then
                    hud('countdown', BRAS_L('Le duel commence'), BRAS_L('Préparez-vous à pousser.'), {
                        badge = BRAS_L('PRÊTS ?'), countdown = math.max(0, math.ceil((countdown - GetGameTimer()) / 1000)),
                        secondaryKey = 'X', secondaryText = BRAS_L('Quitter')
                    })
                else
                    hud(ending and 'ending' or 'waiting', ending and BRAS_L('Duel terminé') or BRAS_L('En attente d’un adversaire'),
                        ending and BRAS_L('La table sera bientôt libérée.') or BRAS_L('Un autre joueur peut vous rejoindre.'), {
                            badge = ending and BRAS_L('TERMINÉ') or BRAS_L('EN ATTENTE'),
                            secondaryKey = 'X', secondaryText = BRAS_L('Quitter')
                        })
                end
            end
        elseif hint and not placement then
            Wait(0)
            local t = tables[hint]
            if t then
                local available = t.state == 'idle' or t.state == 'waiting'
                local controls = available and { primaryKey = 'E', primaryText = BRAS_L('Rejoindre') } or {}
                if t.mine and t.state == 'idle' then controls.secondaryKey, controls.secondaryText = 'G', BRAS_L('Ranger') end
                hud('nearby', available and BRAS_L('Faire un bras de fer') or BRAS_L('Table occupée'),
                    available and BRAS_L('Défiez un autre joueur.') or BRAS_L('Un duel est déjà en cours.'), controls)
                if available and IsControlJustPressed(0, 38) then TriggerServerEvent('brasdefer:rejoindreTable', t.id) end
                if t.mine and t.state == 'idle' and IsControlJustPressed(0, 47) then TriggerServerEvent('brasdefer:recupererTable', t.id) end
            end
        elseif placement then Wait(25)
        else
            BRAS_UI.hide()
            Wait(next(visualTables) and 0 or 200)
        end
        for _, t in pairs(visualTables) do
            if tables[t.id] and tables[t.id].session == t.session and tables[t.id].state == 'active' then syncVisuals(tables[t.id]) end
        end
    end
end)
CreateThread(function()
    while true do
        Wait(250)
        hint, visualTables = nil, {}
        local playerCoords = GetEntityCoords(PlayerPedId())
        local nearestDistance = Config.DistanceTarget * Config.DistanceTarget
        if pending and placementSince and GetGameTimer() - placementSince > Config.DelaiPlacement + 5000 then
            clearPlacement(true)
            notify(BRAS_L('Réponse serveur absente. Vérifie les tables proches avant de réessayer.'))
            TriggerServerEvent('brasdefer:demanderTables', true)
        end
        -- Initialiser après streaming/prise de contrôle, puis corriger seulement
        -- une dérive. Ne pas réémettre gel et orientation toutes les 250 ms.
        for id, t in pairs(tables) do
            local distance = distanceSquared(playerCoords, t.coords)
            if t.state == 'active' and distance <= Config.FixedStreamingDistance * Config.FixedStreamingDistance then visualTables[id] = t end
            if not current and not placement and distance < nearestDistance then
                nearestDistance, hint = distance, id
            end
            if t.fixed then
                if current == id or distance <= Config.FixedStreamingDistance * Config.FixedStreamingDistance then
                    streamFixedTable(t)
                else removeLocalTable(id) end
            elseif NetworkDoesEntityExistWithNetworkId(t.netId) then
                local entity = NetworkGetEntityFromNetworkId(t.netId)
                if entity ~= 0 and DoesEntityExist(entity) and NetworkHasControlOfEntity(entity) then
                    local first = initializedEntities[id] ~= entity
                    if first then FreezeEntityPosition(entity, true) end
                    local angle = math.abs((GetEntityHeading(entity) - t.heading + 180) % 360 - 180)
                    if first or angle > 0.1 then SetEntityHeading(entity, t.heading) end
                    local c = GetEntityCoords(entity)
                    if #(c - vector3(t.coords.x, t.coords.y, t.coords.z)) > 0.05 then
                        SetEntityCoordsNoOffset(entity, t.coords.x, t.coords.y, t.coords.z, false, false, false)
                    end
                    initializedEntities[id] = entity
                else initializedEntities[id] = nil end
            else initializedEntities[id] = nil end
        end
    end
end)
CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(250) end
    TriggerServerEvent('brasdefer:demanderTables', true)
    while true do Wait(Config.SyncInterval); TriggerServerEvent('brasdefer:demanderTables') end
end)
AddEventHandler('onClientResourceStart', function(resource)
    if resource == 'ox_target' then for _, t in pairs(tables) do addTarget(t) end end
end)
AddEventHandler('onClientResourceStop', function(resource)
    if resource == 'ox_target' then targets = {}; return end
end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    removeTargets()
    for id in pairs(localTables) do removeLocalTable(id) end
    clearPlacement(false)
    cleanup()
end)
