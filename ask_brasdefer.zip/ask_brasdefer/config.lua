Config = {}
Config.Locale = 'fr' -- fr | en
Config.Debug = false -- Optional startup diagnostics.
Config.NotificationDuration = 5000 -- Milliseconds.
Config.NotificationLimit = 3
Config.Animations = {
    dictionary = 'mini@arm_wrestling',
    intro = { 'aw_ig_intro_alt1_a', 'aw_ig_intro_alt1_b' },
    idle = { 'nuetral_idle_a', 'nuetral_idle_b' },
    sweep = { 'sweep_a', 'sweep_b' },
    wins = { { 'win_a_ped_a', 'win_a_ped_b' }, { 'win_b_ped_a', 'win_b_ped_b' } }
}

-- 'fixed' : tables créées aux emplacements ci-dessous, aucun item nécessaire.
-- 'portable' : placement manuel et inventaire facultatif comme dans la version 2.
Config.Mode = 'fixed'
Config.TableModel = 'bkr_prop_clubhouse_arm_wrestle_01a' -- Nom du prop de table
Config.Tables = {
    { coords = { x = 1990.5691, y = 3047.4221, z = 46.6153 }, heading = 1.65, bucket = 0 },
    -- /brascoords affiche une entrée prête à copier dans la console F8.
}

-- Options du mode portable uniquement. Aucun framework n'est requis.
Config.Inventory = 'standalone' -- auto | standalone | ox | custom
Config.Item = 'table_bras'
Config.Command = 'brasdefer'
Config.PlacementAce = nil -- Exemple : 'brasdefer.place'
Config.MaxTablesPerOwner = 2
Config.MaxTables = 100
Config.Persistence = true
Config.UseTarget = true -- ox_target facultatif ; touches natives toujours disponibles
Config.FixedStreamingDistance = 100.0 -- Affichage local des tables fixes à proximité
Config.SyncInterval = 20000 -- Vérification de secours ; les changements sont envoyés immédiatement
Config.ForceMax = 30
Config.DelaiPoussee = 150
Config.DistanceTarget = 2.0
Config.DistancePlacement = 2.0
Config.DistanceJoueur = 0.62
Config.OffsetJoueurZ = -0.5 -- À ajuster selon le modèle de table
Config.DistanceSecurite = 3.0
Config.DelaiPlacement = 30000
Config.LoadTimeout = 5000
Config.SpawnRetryDelay = 5000 -- Évite une boucle de création si la base refuse/supprime les objets
Config.ReadyTimeout = 15000
Config.IntroDuration = 2500 -- Participant-specific introduction before ready acknowledgement.
Config.Countdown = 3000
Config.AutoWinAfter = 20000 -- Milliseconds from match start; 0 disables. Leader wins; tied score uses a server-side draw.
Config.MaxDuelDuration = 120000 -- Hard limit: AutoWinAfter is capped at this value.
Config.WaitingTimeout = 120000
Config.EndDuration = 4000
Config.Couleur = { r = 34, g = 219, b = 128, hex = '#22DB80' }

-- Conversion interne : conserver le nom lisible du prop dans le réglage ci-dessus.
if type(Config.TableModel) == 'string' then Config.TableModel = GetHashKey(Config.TableModel) end
