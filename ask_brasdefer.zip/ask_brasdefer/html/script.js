'use strict';
const hud = document.getElementById('hud');
const notifications = document.getElementById('notifications');
const byId = id => document.getElementById(id);
let notificationLimit = 3;
const liveNotifications = [];
const text = (id,value) => { byId(id).textContent = typeof value === 'string' ? value : ''; };
function renderHud(data) {
    if (!data || typeof data !== 'object') return;
    hud.classList.remove('hidden');
    hud.setAttribute('aria-hidden','false');
    text('brand',data.brand); text('badge',data.badge);
    text('title',data.title); text('caption',data.caption);
    const counting = Number.isInteger(data.countdown) && data.countdown >= 0;
    byId('countdown').classList.toggle('hidden',!counting);
    byId('countdown').textContent = counting ? (data.countdown > 0 ? String(data.countdown) : 'GO !') : '';
    const active = data.kind === 'active';
    byId('strength').classList.toggle('hidden',!active);
    text('opponent',data.opponent); text('you',data.you);
    const ratio = typeof data.ratio === 'number' && Number.isFinite(data.ratio) ? Math.max(-1,Math.min(1,data.ratio)) : 0;
    byId('fill').style.width = (Math.abs(ratio) * 50) + '%';
    byId('fill').style.left = (ratio < 0 ? 50 + ratio * 50 : 50) + '%';
    byId('fill').classList.toggle('losing',ratio < 0);
    byId('meter').setAttribute('aria-valuenow',String(Math.round(ratio * 100)));
    byId('meter').setAttribute('aria-label',data.title || '');
    const controls = byId('controls');
    controls.replaceChildren();
    for (const prefix of ['primary','rotate','secondary']) {
        if (typeof data[prefix+'Key'] !== 'string' || typeof data[prefix+'Text'] !== 'string') continue;
        const row = document.createElement('span'); row.className = 'control';
        const key = document.createElement('kbd'); key.textContent = data[prefix+'Key'];
        const label = document.createElement('span'); label.textContent = data[prefix+'Text'];
        row.append(key,label); controls.append(row);
    }
    controls.classList.toggle('hidden',controls.children.length === 0);
}
function dismiss(card) {
    const index = liveNotifications.indexOf(card);
    if (index < 0) return;
    liveNotifications.splice(index,1);
    clearTimeout(card.expiration);
    card.classList.add('leaving');
    setTimeout(() => card.remove(),220);
}
function notify(data) {
    if (typeof data.text !== 'string' || data.text.length === 0) return;
    while (liveNotifications.length >= notificationLimit) dismiss(liveNotifications[0]);
    const kind = ['info','success','error','warning'].includes(data.kind) ? data.kind : 'info';
    const duration = Number.isFinite(data.duration) ? Math.max(1000,Math.min(15000,data.duration)) : 5000;
    const card = document.createElement('article'); card.className = 'notification '+kind;
    const icon = document.createElement('span'); icon.className = 'notificationIcon';
    icon.setAttribute('aria-hidden','true'); icon.textContent = ({info:'i',success:'✓',error:'×',warning:'!'})[kind];
    const body = document.createElement('div'); body.className = 'notificationBody';
    const label = document.createElement('div'); label.className = 'notificationLabel'; label.textContent = typeof data.title === 'string' ? data.title : 'ASK ARM WRESTLING';
    const message = document.createElement('p'); message.className = 'notificationMessage'; message.textContent = data.text;
    const progress = document.createElement('div'); progress.className = 'notificationProgress';
    progress.style.setProperty('--duration',duration+'ms');
    body.append(label,message); card.append(icon,body,progress); notifications.append(card);
    liveNotifications.push(card);
    card.expiration = setTimeout(() => dismiss(card),duration);
}
window.addEventListener('message',event => {
    const data = event.data;
    if (!data || typeof data !== 'object') return;
    if (data.action === 'hud') renderHud(data.data);
    else if (data.action === 'hide') { hud.classList.add('hidden'); hud.setAttribute('aria-hidden','true'); }
    else if (data.action === 'notify') notify(data);
});
async function bootstrap() {
    try {
        const response = await fetch('https://'+GetParentResourceName()+'/ready',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
        const settings = await response.json();
        document.documentElement.lang = settings.locale === 'en' ? 'en' : 'fr';
        if (typeof settings.color === 'string' && /^#[0-9a-f]{6}$/i.test(settings.color)) document.documentElement.style.setProperty('--green',settings.color);
        if (Number.isInteger(settings.limit)) notificationLimit = Math.max(1,Math.min(5,settings.limit));
    } catch (_) { setTimeout(bootstrap,1000); }
}
bootstrap();
